def somar(x,y):
    return x+y

def subtrair(x,y):
    return x-y

def multiplicar(x,y):
    return x*y

def divivir(x,y):
    return x/y